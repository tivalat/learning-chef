## v0.9.0:

### Improvement

- [COOK-1915]: Support SmartOS for nscd

## v0.8.2:

* [COOK-1993] - use install action for packages

## v0.7.0:

* Current public release.
