## v0.11.2:

### Bug

- [COOK-2496]: openldap: rootpw is badly set in attributes file
- [COOK-2970]: openldap cookbook has foodcritic failures

## v0.11.0:

* [COOK-1588] - general cleanup/improvements
* [COOK-1985] - attributes file has a search method

## v0.10.0:

* [COOK-307] - create directory with attribute

## v0.9.4:

* Initial/Current release
